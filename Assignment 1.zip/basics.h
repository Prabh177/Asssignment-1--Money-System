
int totalCents(int dollars, int cents);
int sumAsCents(int moneyOneDollars, int moneyOneCents, int moneyTwoDollars, int moneyTwoCents);
int split(int moneyOneDollars, int moneyOneCents, int moneyTwoDollars, int moneyTwoCents);
